var hierarchy =
[
    [ "thermo::celsius_scale", "structthermo_1_1celsius__scale.html", null ],
    [ "std::common_type&lt; thermo::delta&lt; Rep1, Precision1 &gt;, thermo::delta&lt; Rep2, Precision2 &gt; &gt;", "structstd_1_1common__type_3_01thermo_1_1delta_3_01Rep1_00_01Precision1_01_4_00_01thermo_1_1delta2a01a6ce9e37ec834d67e9e8864d2909.html", null ],
    [ "std::common_type&lt; thermo::temperature&lt; Scale, Delta1 &gt;, thermo::temperature&lt; Scale, Delta2 &gt; &gt;", "structstd_1_1common__type_3_01thermo_1_1temperature_3_01Scale_00_01Delta1_01_4_00_01thermo_1_1tef81531c6ec18681ff6454eb4db586598.html", null ],
    [ "thermo::delta&lt; Rep, Precision &gt;", "classthermo_1_1delta.html", null ],
    [ "thermo::fahrenheit_scale", "structthermo_1_1fahrenheit__scale.html", null ],
    [ "std::false_type", null, [
      [ "thermo::is_delta< delta< Rep, Precision > >", "structthermo_1_1is__delta_3_01delta_3_01Rep_00_01Precision_01_4_01_4.html", null ],
      [ "thermo::is_temperature< temperature< Scale, Delta > >", "structthermo_1_1is__temperature_3_01temperature_3_01Scale_00_01Delta_01_4_01_4.html", null ],
      [ "thermo::is_delta< _T >", "structthermo_1_1is__delta.html", null ],
      [ "thermo::is_temperature< T >", "structthermo_1_1is__temperature.html", null ]
    ] ],
    [ "thermo::kelvin_scale", "structthermo_1_1kelvin__scale.html", null ],
    [ "thermo::temperature&lt; Scale, Delta &gt;", "classthermo_1_1temperature.html", null ],
    [ "std::true_type", null, [
      [ "thermo::is_delta< delta< Rep, Precision > >", "structthermo_1_1is__delta_3_01delta_3_01Rep_00_01Precision_01_4_01_4.html", null ],
      [ "thermo::is_temperature< temperature< Scale, Delta > >", "structthermo_1_1is__temperature_3_01temperature_3_01Scale_00_01Delta_01_4_01_4.html", null ]
    ] ]
];