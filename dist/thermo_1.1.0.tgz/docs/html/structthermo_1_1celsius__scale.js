var structthermo_1_1celsius__scale =
[
    [ "offset", "structthermo_1_1celsius__scale.html#a731b177e5ffa5b0d28fee5cb0b3db34c", null ],
    [ "suffix", "structthermo_1_1celsius__scale.html#a7392a12e310b200641ce9f35d08755b2", null ]
];