var structthermo_1_1fahrenheit__scale =
[
    [ "offset", "structthermo_1_1fahrenheit__scale.html#aba64521f38ae9f61981c7aeda91e4732", null ],
    [ "suffix", "structthermo_1_1fahrenheit__scale.html#adfc8ce4057068b8f49a79263a11873c0", null ]
];