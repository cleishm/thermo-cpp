var annotated_dup =
[
    [ "std", "namespacestd.html", [
      [ "common_type&lt; thermo::delta&lt; Rep1, Precision1 &gt;, thermo::delta&lt; Rep2, Precision2 &gt; &gt;", "structstd_1_1common__type_3_01thermo_1_1delta_3_01Rep1_00_01Precision1_01_4_00_01thermo_1_1delta2a01a6ce9e37ec834d67e9e8864d2909.html", "structstd_1_1common__type_3_01thermo_1_1delta_3_01Rep1_00_01Precision1_01_4_00_01thermo_1_1delta2a01a6ce9e37ec834d67e9e8864d2909" ],
      [ "common_type&lt; thermo::temperature&lt; Scale, Delta1 &gt;, thermo::temperature&lt; Scale, Delta2 &gt; &gt;", "structstd_1_1common__type_3_01thermo_1_1temperature_3_01Scale_00_01Delta1_01_4_00_01thermo_1_1tef81531c6ec18681ff6454eb4db586598.html", "structstd_1_1common__type_3_01thermo_1_1temperature_3_01Scale_00_01Delta1_01_4_00_01thermo_1_1tef81531c6ec18681ff6454eb4db586598" ]
    ] ],
    [ "thermo", "namespacethermo.html", [
      [ "delta", "classthermo_1_1delta.html", "classthermo_1_1delta" ],
      [ "is_delta", "structthermo_1_1is__delta.html", null ],
      [ "is_delta&lt; delta&lt; Rep, Precision &gt; &gt;", "structthermo_1_1is__delta_3_01delta_3_01Rep_00_01Precision_01_4_01_4.html", null ],
      [ "celsius_scale", "structthermo_1_1celsius__scale.html", "structthermo_1_1celsius__scale" ],
      [ "kelvin_scale", "structthermo_1_1kelvin__scale.html", "structthermo_1_1kelvin__scale" ],
      [ "fahrenheit_scale", "structthermo_1_1fahrenheit__scale.html", "structthermo_1_1fahrenheit__scale" ],
      [ "temperature", "classthermo_1_1temperature.html", "classthermo_1_1temperature" ],
      [ "is_temperature", "structthermo_1_1is__temperature.html", null ],
      [ "is_temperature&lt; temperature&lt; Scale, Delta &gt; &gt;", "structthermo_1_1is__temperature_3_01temperature_3_01Scale_00_01Delta_01_4_01_4.html", null ]
    ] ]
];