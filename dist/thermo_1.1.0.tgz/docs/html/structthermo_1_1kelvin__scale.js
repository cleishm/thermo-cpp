var structthermo_1_1kelvin__scale =
[
    [ "offset", "structthermo_1_1kelvin__scale.html#afb6fbc43abe93ae7e5325dac14a3f06b", null ],
    [ "suffix", "structthermo_1_1kelvin__scale.html#ae7da201be1af98530a8c839c37f426d7", null ]
];