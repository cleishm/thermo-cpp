/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var menudata={children:[
{text:"Main Page",url:"index.html"},
{text:"Namespaces",url:"namespaces.html",children:[
{text:"Namespace List",url:"namespaces.html"},
{text:"Namespace Members",url:"namespacemembers.html",children:[
{text:"All",url:"namespacemembers.html",children:[
{text:"c",url:"namespacemembers.html#index_c"},
{text:"d",url:"namespacemembers.html#index_d"},
{text:"f",url:"namespacemembers.html#index_f"},
{text:"i",url:"namespacemembers.html#index_i"},
{text:"k",url:"namespacemembers.html#index_k"},
{text:"m",url:"namespacemembers.html#index_m"},
{text:"o",url:"namespacemembers.html#index_o"},
{text:"t",url:"namespacemembers.html#index_t"}]},
{text:"Functions",url:"namespacemembers_func.html",children:[
{text:"d",url:"namespacemembers_func.html#index_d"},
{text:"o",url:"namespacemembers_func.html#index_o"},
{text:"t",url:"namespacemembers_func.html#index_t"}]},
{text:"Variables",url:"namespacemembers_vars.html"},
{text:"Typedefs",url:"namespacemembers_type.html"}]}]},
{text:"Classes",url:"annotated.html",children:[
{text:"Class List",url:"annotated.html"},
{text:"Class Index",url:"classes.html"},
{text:"Class Hierarchy",url:"hierarchy.html"},
{text:"Class Members",url:"functions.html",children:[
{text:"All",url:"functions.html",children:[
{text:"c",url:"functions.html#index_c"},
{text:"d",url:"functions.html#index_d"},
{text:"m",url:"functions.html#index_m"},
{text:"o",url:"functions.html#index_o"},
{text:"p",url:"functions.html#index_p"},
{text:"r",url:"functions.html#index_r"},
{text:"s",url:"functions.html#index_s"},
{text:"t",url:"functions.html#index_t"},
{text:"z",url:"functions.html#index_z"},
{text:"~",url:"functions.html#index__7E"}]},
{text:"Functions",url:"functions_func.html",children:[
{text:"c",url:"functions_func.html#index_c"},
{text:"d",url:"functions_func.html#index_d"},
{text:"m",url:"functions_func.html#index_m"},
{text:"o",url:"functions_func.html#index_o"},
{text:"t",url:"functions_func.html#index_t"},
{text:"z",url:"functions_func.html#index_z"},
{text:"~",url:"functions_func.html#index__7E"}]},
{text:"Variables",url:"functions_vars.html"},
{text:"Typedefs",url:"functions_type.html"}]}]},
{text:"Files",url:"files.html",children:[
{text:"File List",url:"files.html"}]}]}
