var searchData=
[
  ['fahrenheit_5fscale_0',['fahrenheit_scale',['../structthermo_1_1fahrenheit__scale.html',1,'thermo']]]
];
