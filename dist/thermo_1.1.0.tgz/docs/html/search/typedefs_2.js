var searchData=
[
  ['fahrenheit_0',['fahrenheit',['../namespacethermo.html#a189b3af676e080d3f9414315622239fa',1,'thermo']]]
];
