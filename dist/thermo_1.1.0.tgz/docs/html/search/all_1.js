var searchData=
[
  ['building_20tests_0',['Building Tests',['../index.html#autotoc_md13',1,'']]],
  ['building_20with_20msvc_1',['Building with MSVC',['../index.html#autotoc_md14',1,'']]]
];
