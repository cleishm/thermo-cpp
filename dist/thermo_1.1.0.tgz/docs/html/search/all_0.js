var searchData=
[
  ['absolute_20temperatures_0',['Absolute Temperatures',['../index.html#autotoc_md9',1,'']]]
];
