var searchData=
[
  ['suffix_0',['suffix',['../structthermo_1_1celsius__scale.html#a7392a12e310b200641ce9f35d08755b2',1,'thermo::celsius_scale::suffix'],['../structthermo_1_1kelvin__scale.html#ae7da201be1af98530a8c839c37f426d7',1,'thermo::kelvin_scale::suffix'],['../structthermo_1_1fahrenheit__scale.html#adfc8ce4057068b8f49a79263a11873c0',1,'thermo::fahrenheit_scale::suffix']]]
];
