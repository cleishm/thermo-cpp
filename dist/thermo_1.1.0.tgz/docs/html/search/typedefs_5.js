var searchData=
[
  ['offset_0',['offset',['../structthermo_1_1celsius__scale.html#a731b177e5ffa5b0d28fee5cb0b3db34c',1,'thermo::celsius_scale::offset'],['../structthermo_1_1kelvin__scale.html#afb6fbc43abe93ae7e5325dac14a3f06b',1,'thermo::kelvin_scale::offset'],['../structthermo_1_1fahrenheit__scale.html#aba64521f38ae9f61981c7aeda91e4732',1,'thermo::fahrenheit_scale::offset']]]
];
