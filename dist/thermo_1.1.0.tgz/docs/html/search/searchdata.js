var indexSectionsWithContent =
{
  0: "abcdfiklmoprstuvwz~",
  1: "cdfikt",
  2: "st",
  3: "rt",
  4: "cdmotz~",
  5: "is",
  6: "cdfkmoprst",
  7: "abcdfilmrtuvw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Pages"
};

