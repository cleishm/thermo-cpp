var searchData=
[
  ['kelvin_0',['kelvin',['../namespacethermo.html#a36eb16ac6ddbdf9a61a45454384e9f89',1,'thermo']]],
  ['kelvin_5fscale_1',['kelvin_scale',['../structthermo_1_1kelvin__scale.html',1,'thermo']]]
];
