var searchData=
[
  ['license_0',['License',['../index.html#autotoc_md15',1,'']]],
  ['literals_1',['Literals',['../index.html#autotoc_md11',1,'']]]
];
