var searchData=
[
  ['manual_0',['Manual',['../index.html#autotoc_md6',1,'']]],
  ['msvc_1',['Building with MSVC',['../index.html#autotoc_md14',1,'']]]
];
