var searchData=
[
  ['deltas_0',['Temperature Deltas',['../index.html#autotoc_md10',1,'']]]
];
