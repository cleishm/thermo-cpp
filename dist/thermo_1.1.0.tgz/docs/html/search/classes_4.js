var searchData=
[
  ['kelvin_5fscale_0',['kelvin_scale',['../structthermo_1_1kelvin__scale.html',1,'thermo']]]
];
